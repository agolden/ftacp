//
//  lib_ACPWrapper.h
//  lib_ACPWrapper
//
//

#import <Foundation/Foundation.h>

#import "ACPCore.h"
#import "ACPIdentity.h"
#import "ACPExtensionListener.h"
#import "ACPExtensionEvent.h"
#import "ACPExtension.h"
#import "ACPSignal.h"
#import "ACPMobileVisitorId.h"
#import "ACPLifecycle.h"
#import "ACPAnalytics.h"
#import "ACPTarget.h"
#import "ACPUserProfile.h"

//! Project version number for XCTemplate.
FOUNDATION_EXPORT double lib_ACPWrapperVersionNumber;

//! Project version string for XCTemplate.
FOUNDATION_EXPORT const unsigned char lib_ACPWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XCTemplate/PublicHeader.h>


